local json = require "modules/json"

loadsc = {}

function loadsc.onJsonDataIncoming(data)
	local decodedJson = json.decode(data)
	
	local context = rmlui.contexts["main"]
	
	local document = context.documents['loadsc']
	local progress = tonumber(decodedJson['progress'])
	if progress > 100 then progress = 100 end
	document:GetElementById("lua_progress").inner_rml = tostring(progress) .. '%'
	document:GetElementById("lua_progressbar").style.width = tostring(progress * 0.8) .. 'vw'
end

function loadsc.isCursorNeeded()
	return 0
end

guis[0] = loadsc