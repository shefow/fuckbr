local json = require "modules/json"

authreg = {}

function authreg.onJsonDataIncoming(data)
	local decodedJson = json.decode(data)
	
	local context = rmlui.contexts["main"]
	
	if decodedJson['o'] then
		authreg.document = context:LoadDocument("rml/authreg/authreg.rml")
		authreg.document:Show()
	end
end

function authreg.onLoginButtonClicked(document)
	local password = Element.As.ElementFormControlInput(document:GetElementById("password")).value
	Native.sendJsonData(38, json.encode({t = 6, s = password, r = 0}))
	Native.sendJsonData(38, json.encode({c = 38}))
	authreg.document:Close()
	authreg.document = nil
end

function authreg.isCursorNeeded()

	if authreg.document ~= nil then
		return 1
	else
		return 0
	end
end

guis[38] = authreg