table.insert(package.searchers, 2, function(modulename)
  return assert(load(Native.loadModule(modulename)))
end)

local json = require "modules/json"

guis = {}

function onJsonDataIncoming(guiid, data)

	if guis[guiid] ~= nil then
		guis[guiid].onJsonDataIncoming(data)
	end
end

function isCursorNeeded()
	for i, gui in pairs(guis) do
		if gui.isCursorNeeded() == 1 then
			return 1
		end
	end
	return 0
end